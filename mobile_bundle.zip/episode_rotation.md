# Mission Rotation Engine (Intel Narrative Styles)

**Purpose:** Maintain engagement by rotating the *narrative lens* per mission. Every mission contains an **Intercept** (Raw Feed) and a **Breakdown** (Analysis), but the scenario type changes.

## The Narrative Rotation

The Director selects the style based on the current `current_location` and the next semantic word chunk.

| Order | Style | Focus |
|:---|:---|:---|
| **1** | **The Eavesdrop** | Listening to a public conversation (Market, Station). High noun density, directional verbs. |
| **2** | **The Heated Dispute** | High-stakes conflict (Autorickshaw argument, chai shop standoff). **Not domestic.** Verb tenses and attitude particles. |
| **3** | **The Surveillance** | Monitoring a phone call or private meeting. Focus on "Say/Ask" matrices and reported speech. |
| **4** | **The Transaction** | A pure commerce scenario (Buying, Bribing, Negotiating). Numbers and object manipulation verbs. |
| **5** | **The Field Test** | A culmination where the "Breakdown" prepares the learner to perform a specific action in the story. |

**Rotation rule:** Move through the table in order. Do not use the same style on consecutive missions. If the last mission used a style, skip it and take the next one.

**Location rule:** If `learner.json`'s `current_location` is a house or interior, the next Intercept must be set outdoors or in a public/commercial space. The story must move.

For word weaving behaviour (TEACH / EXPOSE / USE / CALLBACK), see `protocol/immersion_gradient.md`.

## The Dual-Track Standard

- **The Intercept:** 3–5 minutes (~500–750 words). Pure Tamil/Thanglish. Long enough to get lost in, loop, and discover on relisten. Must have a beginning, middle, and end.
- **The Breakdown:** 5–7 minutes (~750–1,050 words). Reaction-style analysis.
- **Script Naming:** `content/scripts/tier{N}_mission{M}.md`
